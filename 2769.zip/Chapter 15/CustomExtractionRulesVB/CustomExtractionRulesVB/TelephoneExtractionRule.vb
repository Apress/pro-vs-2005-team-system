Imports Microsoft.VisualStudio.TestTools.WebTesting.Rules

Public Class TelephoneExtractionRule : Inherits ExtractRegularExpression
    Public Sub New()
        MyBase.New()

        Me.RegularExpression = "\(?[0-9]{3}\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}"
    End Sub

    Public Overrides ReadOnly Property RuleName() As String
        Get
            Return "Extract Telephone Numbers"
        End Get
    End Property

    Public Overrides ReadOnly Property RuleDescription() As String
        Get
            Return "Extracts all telephone numbers which match " _
                    & "the North American convention."
        End Get
    End Property
End Class
