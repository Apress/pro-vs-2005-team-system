Option Explicit On
Option Strict On

Imports Microsoft.VisualStudio.TestTools.WebTesting
Imports System.IO

Public Class Logger : Inherits WebTestPlugin
    Private _logStream As FileStream = Nothing
    Private _logWriter As StreamWriter = Nothing
    Private WithEvents _test As WebTest = Nothing

    Public Overrides Sub PreWebTest(ByVal sender As Object, ByVal e As Microsoft.VisualStudio.TestTools.WebTesting.PreWebTestEventArgs)
        _logStream = New FileStream("c:\logfile.txt", FileMode.Append)
        _logWriter = New StreamWriter(_logStream)
        _logWriter.AutoFlush = True
        _logWriter.WriteLine("Beginning Test (" + Now.ToString() + ")")
        _test = e.WebTest
    End Sub

    Public Sub Webtest_PostRequest(ByVal sender As Object, ByVal e As Microsoft.VisualStudio.TestTools.WebTesting.PostRequestEventArgs) Handles _test.PostRequest
        _logWriter.WriteLine(e.Request.Url.ToString())
    End Sub

    Public Overrides Sub PostWebTest(ByVal sender As Object, ByVal e As Microsoft.VisualStudio.TestTools.WebTesting.PostWebTestEventArgs)
        _logWriter.WriteLine("Ending Test (" + Now.ToString() + ")")
        _logWriter.Close()
    End Sub
End Class
