using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.WebTesting.Rules;

namespace CustomExtractionRulesCS
{
    public class ExtractTelephoneRule : ExtractRegularExpression
    {
        public ExtractTelephoneRule()
            : base()
        {
            this.RegularExpression = @"\(?[0-9]{3}\)?[-. ]?[0-9]{3}[-. ]?[0-9]{4}";
        }

        public override string RuleName
        {
            get { return "Extract Telephone Numbers"; }
        }

        public override string RuleDescription
        {
            get
            {
                return "Extracts all telephone numbers which match "
                  + "the North American convention.";
            }
        }
    }
}