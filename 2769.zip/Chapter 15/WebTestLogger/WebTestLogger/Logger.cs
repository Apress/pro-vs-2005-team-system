using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.WebTesting;
using System.IO;

namespace LoggingRequest
{
    public class Logger: WebTestPlugin
    {
        private FileStream _logStream = null;
        private StreamWriter _logWriter = null;

        public Logger() 
        { }

        public override void PreWebTest(object sender, PreWebTestEventArgs e)
        {
            _logStream = new FileStream("c:\\logfile.txt", FileMode.Append);
            _logWriter = new StreamWriter(_logStream);
            _logWriter.AutoFlush = true;
            _logWriter.WriteLine("Beginning Test (" + DateTime.Now.ToString() + ")");
           e.WebTest.PostRequest += new EventHandler<PostRequestEventArgs>(WebTest_PostRequest);
        }

        void WebTest_PostRequest(object sender, PostRequestEventArgs e)
        {
            _logWriter.WriteLine(e.Request.Url.ToString());
        }

        public override void PostWebTest(object sender, PostWebTestEventArgs e)
        {
            _logWriter.WriteLine("Ending Test (" + DateTime.Now.ToString() + ")");
            _logWriter.Close();
            e.WebTest.PostRequest -= new EventHandler<PostRequestEventArgs>(WebTest_PostRequest);
        }
    }
}