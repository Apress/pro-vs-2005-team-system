Each folder has its' own readme.txt file which provides instructions for using the code
for the given chapter. It does not assume that you are working through the chapters
sequentially. If you ARE, then you'll be able to avoid some work. This would mean that you only need to create the website once and that you only need to create the databases once.

The Full Application folder contains the code as it would be at the end of Chapter 16 for the EffortTracking application.

Note that there is no code for the following chapters: 1, 2, 4. In order to follow along with Chapter 2 and on you must create a blank Team Project by following the steps in Chapter 2.

All code is presented in C Sharp and Visual Basic. The folders with no extension are the C# folders, all other folders have a "VB" extension and contain the Visual Basic version of the code.

Please note, in Chapter 7 the readme contains instructions for setting up the entire application. You only need to do this once. After that you can overwrite code by copying and pasting it from the various files in the different chapters instead of going through this process over and over again.

David Nelson
Jeff Levinson
