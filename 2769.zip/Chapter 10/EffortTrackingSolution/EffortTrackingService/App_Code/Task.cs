using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace EffortTrackingService
{
    public struct Task
    {
        /// <summary>
        /// ID of the task.
        /// </summary>
        public int Id;
        /// <summary>
        /// Brief description of the task.
        /// </summary>
        public string Title;
        /// <summary>
        /// Complete description of the task.
        /// </summary>
        public string Description;
        /// <summary>
        /// Date the task was last updated.
        /// </summary>
        public System.DateTime DateModified;
        /// <summary>
        /// ID of the week in which the task was performed.
        /// </summary>
        public int WeekEndingId;
        /// <summary>
        /// ID of the category which the task falls under.
        /// </summary>
        public int CategoryId;
        /// <summary>
        /// ID of the user who created and owns the task.
        /// </summary>
        public int UserId;
    }
}