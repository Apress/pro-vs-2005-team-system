using System;
using System.Data;

namespace EffortTrackingService
{
    interface ITaskService
    {
        int AddUser(string userName, string password);
        void DeleteTask(int taskID);
        DataSet GetLookupInfo();
        Task GetTask(int taskID);
        DataSet GetTasks(int weekID, int userID);
        DataSet GetTasksWithDate(DateTime date, int userID);
        int SaveTask(Task task);
        int ValidateUser(string userName, string password, PasswordType type);
    }
}