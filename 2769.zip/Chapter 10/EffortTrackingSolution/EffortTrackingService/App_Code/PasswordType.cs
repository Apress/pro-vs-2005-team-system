using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace EffortTrackingService
{
    public enum PasswordType
    {
        /// <summary>
        /// Indicates the password is unencrypted.
        /// </summary>
        ClearText = 0,
        /// <summary>
        /// Indicates the password is encrypted.
        /// </summary>
        Encrypted = 1,
    }
}
