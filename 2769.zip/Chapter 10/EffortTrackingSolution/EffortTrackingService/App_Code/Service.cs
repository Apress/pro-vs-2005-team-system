using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EffortTrackingService
{
    /// <summary>
    /// Summary description for Service
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class Service : System.Web.Services.WebService, ITaskService
    {
        /// <summary>
        /// Returns a dataset containing week and category information for use as lookups.
        /// </summary>
        [WebMethod()]
        public System.Data.DataSet GetLookupInfo()
        {
            throw new Exception("Method not implemented yet.");
        }

        /// <summary>
        /// Validates that the user is in the system.
        /// </summary>
        /// <param name="userName">User name of the person to validate.</param>
        /// <param name="password">Password to validate.</param>
        /// <param name="type">Indicates if the password is encrypted or not.</param>
        [WebMethod()]
        public int ValidateUser(string userName, string password, PasswordType type)
        {
            throw new Exception("Method not implemented yet.");
        }

        /// <summary>
        /// Adds a new user to the system.
        /// </summary>
        /// <param name="userName">User name of the person to add.</param>
        /// <param name="password">Password for the new user.</param>
        [WebMethod()]
        public int AddUser(string userName, string password)
        {
            throw new Exception("Method not implemented yet.");
        }

        /// <summary>
        /// Deletes a single task item.
        /// </summary>
        /// <param name="taskID">ID of the task to delete.</param>
        [WebMethod()]
        public void DeleteTask(int taskID)
        {
            throw new Exception("Method not implemented yet.");
        }

        /// <summary>
        /// Returns a single task.
        /// </summary>
        /// <param name="taskID">The ID of the task to return.</param>
        [WebMethod()]
        public Task GetTask(int taskID)
        {
            throw new Exception("Method not implemented yet.");
        }

        /// <summary>
        /// Returns a dataset with Task information for the given week and user.
        /// </summary>
        /// <param name="weekID">ID of the week for which to return the tasks.</param>
        /// <param name="userID">ID of the user to return the tasks for.</param>
        [WebMethod()]
        public DataSet GetTasks(int weekID, int userID)
        {
            throw new Exception("Method not implemented yet.");
        }

        /// <summary>
        /// Gets a weeks worth of tasks based for the week the date provided by the user
        /// falls in.
        /// </summary>
        /// <param name="date">The date for the week to retrieve the tasks.</param>
        /// <param name="userID">The ID of the user.</param>
        /// <returns>A dataset with the partial tasks.</returns>
        [WebMethod()]
        public DataSet GetTasksWithDate(DateTime date, int userID)
        {
            throw new Exception("Method not implemented yet.");
        }

        /// <summary>
        /// Saves or updates a task in the database.
        /// </summary>
        /// <param name="task">Task to save.</param>
        [WebMethod()]
        public int SaveTask(Task task)
        {
            throw new Exception("Method not implemented yet.");
        }
    }
}