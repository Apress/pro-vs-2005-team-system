using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Login : System.Web.UI.Page
{
    /// <summary>
    /// Adds a new user to the site
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    /// <remarks>We are NOT checking to see if the user already exists in the system.</remarks>
    protected void btnNew_Click(object sender, EventArgs e)
    {
        //Make sure they entered the password correctly
        if (txtPassword.Text == txtVerifyPassword.Text)
        {
            //Add the user
            localhost.Service s = new localhost.Service();
            int userID = s.AddUser(txtUserName.Text, txtPassword.Text);
            //Add the ID to the session for saving tasks
            Page.Session.Add("userID", userID);
            //Set the auth cookie
            FormsAuthentication.SetAuthCookie(txtUserName.Text, false);
            //Send them to the url they were trying to get to.
            if (Page.Request["ReturnURL"] == null)
                Page.Response.Redirect("http://localhost/EffortTrackingWeb/secure/default.aspx");
            else
                Page.Response.Redirect(Page.Request["ReturnURL"]);
        }
        else
        {
            //If not tell them there were errors
            lblErrors.Text = "The password you entered is not identical to the verified password.";
        }
    }

    /// <summary>
    /// Log an existing user onto the system.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        //Validate their username and password
        localhost.Service s = new localhost.Service();
        int userID = s.ValidateUser(txtUserName.Text, txtPassword.Text, localhost.PasswordType.ClearText);
        if (userID != 0)
        {
            //Add the ID to the session for saving tasks
            Page.Session.Add("userID", userID);
            //Set the auth cookie
            FormsAuthentication.SetAuthCookie(txtUserName.Text, false);
            //Send them to the url they were trying to get to.
            if (Page.Request["ReturnURL"] == null)
                Page.Response.Redirect("http://localhost/EffortTrackingWeb/secure/default.aspx");
            else
                Page.Response.Redirect(Page.Request["ReturnURL"]);
        }
        else
        {
            //If not tell them there were errors
            lblErrors.Text = "The username or password you entered was invalid. Please try again.";
        }
    }
}
