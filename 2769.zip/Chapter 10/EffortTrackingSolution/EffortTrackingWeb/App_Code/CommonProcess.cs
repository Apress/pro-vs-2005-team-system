using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for CommonProcess
/// </summary>
public class CommonProcess
{
	public static void LoadWeekEndingCombo(DropDownList combo)
    {
        localhost.Service s = new localhost.Service();
        DataSet ds = s.GetLookupInfo();
        combo.DataSource = ds.Tables["Week Ending"];
        combo.DataTextField = "we_end";
        combo.DataTextFormatString = "{0:MM/dd/yyyy}";
        combo.DataValueField = "we_id";
        combo.DataBind();
    }

    public static void LoadCategoryCombo(DropDownList combo)
    {
        localhost.Service s = new localhost.Service();
        DataSet ds = s.GetLookupInfo();
        combo.DataSource = ds.Tables["Categories"];
        combo.DataTextField = "cat_title";
        combo.DataValueField = "cat_id";
        combo.DataBind();
    }
}
