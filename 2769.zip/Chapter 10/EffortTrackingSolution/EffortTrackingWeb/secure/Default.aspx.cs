using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Check to see if this is a post back.
        if (!Page.IsPostBack)
        {
            //If it's not, load the week ending combo box
            CommonProcess.LoadWeekEndingCombo(this.cboWeekEnding);
            //Check to see if there was a week ending id passed
            if (Page.Request.QueryString["we_id"] != null)
            {
                //If there was, set the combo box appropriately
                cboWeekEnding.SelectedValue = Page.Request.QueryString["we_id"];
            }
        }
    }

    /// <summary>
    /// When the user clicks add, directs them to the edit page with the
    /// id=0, mode=add and week ending is the selected week ending.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Edit.aspx?id=0&mode=add&we_id=" + cboWeekEnding.SelectedValue);
    }
}
