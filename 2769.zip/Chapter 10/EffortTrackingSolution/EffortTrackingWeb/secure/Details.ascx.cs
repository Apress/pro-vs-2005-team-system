using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Details : System.Web.UI.UserControl
{
    /// <summary>
    /// Being the process of loading the control.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //Load the week ending and category combo boxes
            CommonProcess.LoadWeekEndingCombo(cboWeekEnding);
            CommonProcess.LoadCategoryCombo(cboCategory);

            //Store the record ID and week ending ID for later use
            fldID.Value = Page.Request.QueryString["id"];
            fldWE.Value = Page.Request.QueryString["we_id"];

            //Set the text at the top of the page which describes the mode
            SetStatus();

            //If this is a record
            if (Page.Request.QueryString["id"] != "0")
            {
                //Then load the record
                LoadRecord(Convert.ToInt32(Page.Request.QueryString["id"]));
            }
            else
            {
                //Otherwise, don't load anything and just set the value of the week
                //ending combo box to match the week the user had selected on the
                //default page.
                cboWeekEnding.SelectedValue = Page.Request.QueryString["we_id"];
            }
        }
    }

    /// <summary>
    /// Loads a record from the service.
    /// </summary>
    /// <param name="taskID">The ID of the record to load.</param>
    protected void LoadRecord(int taskID)
    {
        localhost.Service s = new localhost.Service();
        localhost.Task task = s.GetTask(Convert.ToInt32(fldID.Value));
        s = null;
        //Set all the values on the control
        txtTitle.Text = task.Title;
        txtDescription.Text = task.Description;
        cboCategory.SelectedValue = task.CategoryId.ToString();
        cboWeekEnding.SelectedValue = task.WeekEndingId.ToString();
    }

    /// <summary>
    /// Set the status text
    /// </summary>
    protected void SetStatus()
    {
        switch (Page.Request.QueryString["mode"])
        {
            case "edit":
                lblStatus.Text = "Edit Task";
                break;
            case "add":
                lblStatus.Text = "Add Task";
                break;
            case "delete":
                lblStatus.Text = "Delete Task";
                btnOK.Text = "Delete";
                break;
        }
    }

    /// <summary>
    /// Redirect the user to the default page when they cancel.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx?we_id=" + fldWE.Value);
    }

    /// <summary>
    /// Select the appropriate action depending on the mode when the user clicked
    /// the ok button
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnOK_Click(object sender, EventArgs e)
    {
        switch (lblStatus.Text)
        {
            case "Edit Task":
                Save();
                break;
            case "Add Task":
                Save();
                break;
            case "Delete Task":
                Delete();
                break;
        }
    }

    /// <summary>
    /// Saves the record to the service and redirects the user to the default page
    /// </summary>
    protected void Save()
    {
        localhost.Task task = new localhost.Task();
        task.Id = Convert.ToInt32(fldID.Value);
        task.CategoryId = Convert.ToInt32(cboCategory.SelectedValue);
        task.WeekEndingId = Convert.ToInt32(cboWeekEnding.SelectedValue);
        task.Title = txtTitle.Text;
        task.Description = txtDescription.Text;
        task.UserId = Convert.ToInt32(Page.Session["userID"]);
        localhost.Service s = new localhost.Service();
        int lastSaved = s.SaveTask(task);
        Response.Redirect("Default.aspx?we_id=" + cboWeekEnding.SelectedValue
            + "&last=" + lastSaved.ToString());
    }

    /// <summary>
    /// Deletes a record from the service and redirects the user to the default page
    /// </summary>
    protected void Delete()
    {
        localhost.Service s = new localhost.Service();
        s.DeleteTask(Convert.ToInt32(fldID.Value));
        Response.Redirect("Default.aspx?we_id=" + cboWeekEnding.SelectedValue);
    }
}