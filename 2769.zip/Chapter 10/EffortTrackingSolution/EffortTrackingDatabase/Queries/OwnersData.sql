SET IDENTITY_INSERT dbo.owners ON

INSERT INTO owners (own_id, own_login, own_password) VALUES (1, 'TestUser1', 'password')
INSERT INTO owners (own_id, own_login, own_password) VALUES (2, 'TestUser2', 'password')

SET IDENTITY_INSERT dbo.owners OFF