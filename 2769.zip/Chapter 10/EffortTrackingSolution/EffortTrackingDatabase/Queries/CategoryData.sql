SET IDENTITY_INSERT dbo.categories ON

INSERT INTO categories (cat_id, cat_title) VALUES (1, 'Sales')
INSERT INTO categories (cat_id, cat_title) VALUES (2, 'Marketing')
INSERT INTO categories (cat_id, cat_title) VALUES (3, 'Contracts')
INSERT INTO categories (cat_id, cat_title) VALUES (4, 'Engineering')
INSERT INTO categories (cat_id, cat_title) VALUES (5, 'Miscellaneous')

SET IDENTITY_INSERT dbo.categories OFF