SET IDENTITY_INSERT dbo.week_ending ON 

INSERT INTO week_ending (we_id, we_start, we_end) VALUES (1, '5/1/2005 12:00:00 AM', '5/7/2005 12:00:00 AM')
INSERT INTO week_ending (we_id, we_start, we_end) VALUES (2, '5/8/2005 12:00:00 AM', '5/14/2005 12:00:00 AM')
INSERT INTO week_ending (we_id, we_start, we_end) VALUES (3, '5/15/2005 12:00:00 AM', '5/21/2005 12:00:00 AM')
INSERT INTO week_ending (we_id, we_start, we_end) VALUES (4, '5/22/2005 12:00:00 AM', '5/28/2005 12:00:00 AM')

SET IDENTITY_INSERT dbo.week_ending OFF