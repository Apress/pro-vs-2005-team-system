SET IDENTITY_INSERT dbo.work_items ON

INSERT INTO work_items (wi_id, wi_title, wi_description, wi_modified_date, cat_id, own_id, we_id) VALUES (1, 'Work Item 1', 'Description of Work Item 1', getdate(), 1, 1, 1)
INSERT INTO work_items (wi_id, wi_title, wi_description, wi_modified_date, cat_id, own_id, we_id) VALUES (2, 'Work Item 2', 'Description of Work Item 2', getdate(), 1, 1, 1)
INSERT INTO work_items (wi_id, wi_title, wi_description, wi_modified_date, cat_id, own_id, we_id) VALUES (3, 'Work Item 3', 'Description of Work Item 3', getdate(), 1, 1, 1)
INSERT INTO work_items (wi_id, wi_title, wi_description, wi_modified_date, cat_id, own_id, we_id) VALUES (4, 'Work Item 4', 'Description of Work Item 4', getdate(), 1, 1, 2)
INSERT INTO work_items (wi_id, wi_title, wi_description, wi_modified_date, cat_id, own_id, we_id) VALUES (5, 'Work Item 5', 'Description of Work Item 5', getdate(), 1, 1, 2)
INSERT INTO work_items (wi_id, wi_title, wi_description, wi_modified_date, cat_id, own_id, we_id) VALUES (6, 'Work Item 6', 'Description of Work Item 6', getdate(), 1, 2, 1)
INSERT INTO work_items (wi_id, wi_title, wi_description, wi_modified_date, cat_id, own_id, we_id) VALUES (7, 'Work Item 7', 'Description of Work Item 7', getdate(), 1, 2, 1)
INSERT INTO work_items (wi_id, wi_title, wi_description, wi_modified_date, cat_id, own_id, we_id) VALUES (8, 'Work Item 8', 'Description of Work Item 8', getdate(), 1, 2, 2)
INSERT INTO work_items (wi_id, wi_title, wi_description, wi_modified_date, cat_id, own_id, we_id) VALUES (9, 'Work Item 9', 'Description of Work Item 9', getdate(), 1, 2, 2)


SET IDENTITY_INSERT dbo.work_items OFF 