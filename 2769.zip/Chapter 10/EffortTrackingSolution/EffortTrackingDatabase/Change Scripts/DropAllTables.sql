IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'work_items') AND type in (N'U'))
DROP TABLE [dbo].work_items
go
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'owners') AND type in (N'U'))
DROP TABLE [dbo].owners
go
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'categories') AND type in (N'U'))
DROP TABLE [dbo].categories
go
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'week_ending') AND type in (N'U'))
DROP TABLE [dbo].week_ending
go