
Partial Class Login
    Inherits System.Web.UI.Page

    ''' <summary>
    ''' Adds a new user to the site
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>We are NOT checking to see if the user already exists in the system.</remarks>
    Protected Sub btnNew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNew.Click
        'Make sure they entered the password correctly
        If (txtPassword.Text = txtVerifyPassword.Text) Then
            'Add the user
            Dim s As localhost.Service = New localhost.Service()
            Dim userID As Integer = s.AddUser(txtUserName.Text, txtPassword.Text)
            'Add the ID to the session for saving tasks
            Page.Session.Add("userID", userID)
            'Set the auth cookie
            FormsAuthentication.SetAuthCookie(txtUserName.Text, False)
            'Send them to the url they were trying to get to.
            If (Page.Request("ReturnURL") = Nothing) Then
                Page.Response.Redirect("http://localhost/EffortTrackingWebVB/secure/Default.aspx")
            Else
                Page.Response.Redirect(Page.Request("ReturnURL"))
            End If
        Else
            'If not tell them there were errors
            lblErrors.Text = "The password you entered is not identical to the verified password."
        End If
    End Sub

    ''' <summary>
    ''' Log an existing user onto the system.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        'Validate their username and password
        Dim s As localhost.Service = New localhost.Service()
        Dim userID As Integer = s.ValidateUser(txtUserName.Text, txtPassword.Text, localhost.PasswordType.ClearText)
        If (userID > 0) Then
            'Add the ID to the session for saving tasks
            Page.Session.Add("userID", userID)
            'Set the auth cookie
            FormsAuthentication.SetAuthCookie(txtUserName.Text, False)
            'Send them to the url they were trying to get to.
            If (Page.Request("ReturnURL") = Nothing) Then
                Page.Response.Redirect("http://localhost/EffortTrackingWebVB/secure/Default.aspx")
            Else
                Page.Response.Redirect(Page.Request("ReturnURL"))
            End If
        Else
            'If not tell them there were errors
            lblErrors.Text = "The username or password you entered was invalid. Please try again."
        End If
    End Sub
End Class
