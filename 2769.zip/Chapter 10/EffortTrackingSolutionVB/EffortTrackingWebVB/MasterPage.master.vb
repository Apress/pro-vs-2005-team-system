
Partial Class MasterPage
    Inherits System.Web.UI.MasterPage
End Class

