
Partial Class secure_Edit
    Inherits System.Web.UI.Page

End Class
