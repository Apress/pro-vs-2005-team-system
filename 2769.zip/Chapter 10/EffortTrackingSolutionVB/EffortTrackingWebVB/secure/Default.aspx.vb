
Partial Class secure_Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        'Check to see if this is a post back.
        If (Not Page.IsPostBack) Then
            'If it's not, load the week ending combo box
            CommonProcess.LoadWeekEndingCombo(Me.cboWeekEnding)
            'Check to see if there was a week ending id passed
            If (Not Page.Request.QueryString("we_id") = Nothing) Then
                'If there was, set the combo box appropriately
                cboWeekEnding.SelectedValue = Page.Request.QueryString("we_id")
            End If
        End If
    End Sub

    ' <summary>
    ' When the user clicks add, directs them to the edit page with the
    ' id=0, mode=add and week ending is the selected week ending.
    ' </summary>
    ' <param name="sender"></param>
    ' <param name="e"></param>
    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Response.Redirect("Edit.aspx?id=0&mode=add&we_id=" & cboWeekEnding.SelectedValue)
    End Sub
End Class
