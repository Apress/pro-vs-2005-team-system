
Partial Class secure_Details
    Inherits System.Web.UI.UserControl

    ''' <summary>
    ''' Being the process of loading the control.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If (Page.IsPostBack = False) Then
            'Load the week ending and category combo boxes
            CommonProcess.LoadWeekEndingCombo(cboWeekEnding)
            CommonProcess.LoadCategoryCombo(cboCategory)

            'Store the record ID and week ending ID for later use
            fldID.Value = Page.Request.QueryString("id")
            fldWE.Value = Page.Request.QueryString("we_id")

            'Set the text at the top of the page which describes the mode
            SetStatus()

            'If this is a record
            If (Page.Request.QueryString("id") <> "0") Then
                'Then load the record
                LoadRecord(Convert.ToInt32(Page.Request.QueryString("id")))
            Else
                'Otherwise, don't load anything and just set the value of the week
                'ending combo box to match the week the user had selected on the
                'default page.
                cboWeekEnding.SelectedValue = Page.Request.QueryString("we_id")
            End If
        End If
    End Sub

    ''' <summary>
    ''' Loads a record from the service.
    ''' </summary>
    ''' <param name="taskID">The ID of the record to load.</param>
    Protected Sub LoadRecord(ByVal taskID As Integer)
        Dim s As localhost.Service = New localhost.Service()
        Dim task As localhost.Task = s.GetTask(Convert.ToInt32(fldID.Value))
        s = Nothing
        'Set all the values on the control
        txtTitle.Text = task.Title
        txtDescription.Text = task.Description
        cboCategory.SelectedValue = task.CategoryId.ToString()
        cboWeekEnding.SelectedValue = task.WeekEndingId.ToString()
    End Sub

    ''' <summary>
    ''' Set the status text
    ''' </summary>
    Protected Sub SetStatus()
        Select Case (Page.Request.QueryString("mode"))
            Case "edit"
                lblStatus.Text = "Edit Task"
                Exit Select
            Case "add"
                lblStatus.Text = "Add Task"
                Exit Select
            Case "delete"
                lblStatus.Text = "Delete Task"
                btnOK.Text = "Delete"
                Exit Select
        End Select
    End Sub

    ''' <summary>
    ''' Saves the record to the service and redirects the user to the default page
    ''' </summary>
    Protected Sub Save()
        Dim task As localhost.Task = New localhost.Task()
        task.Id = Convert.ToInt32(fldID.Value)
        task.CategoryId = Convert.ToInt32(cboCategory.SelectedValue)
        task.WeekEndingId = Convert.ToInt32(cboWeekEnding.SelectedValue)
        task.Title = txtTitle.Text
        task.Description = txtDescription.Text
        task.UserId = Convert.ToInt32(Page.Session("userID"))
        Dim s As localhost.Service = New localhost.Service()
        Dim lastSaved As Integer = s.SaveTask(task)
        Response.Redirect("Default.aspx?we_id=" & cboWeekEnding.SelectedValue _
        & "&last=" & lastSaved.ToString())
    End Sub

    ''' <summary>
    ''' Deletes a record from the service and redirects the user to the default page
    ''' </summary>
    Protected Sub Delete()
        Dim s As localhost.Service = New localhost.Service()
        s.DeleteTask(Convert.ToInt32(fldID.Value))
        Response.Redirect("Default.aspx?we_id=" & cboWeekEnding.SelectedValue)
    End Sub

    ''' <summary>
    ''' Select the appropriate action depending on the mode when the user clicked
    ''' the ok button
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Protected Sub btnOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Select Case (lblStatus.Text)
            Case "Edit Task"
                Save()
                Exit Select
            Case "Add Task"
                Save()
                Exit Select
            Case "Delete Task"
                Delete()
                Exit Select
        End Select
    End Sub

    ''' <summary>
    ''' Redirect the user to the default page when they cancel.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Protected Sub btnCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("Default.aspx?we_id=" & fldWE.Value)
    End Sub
End Class
