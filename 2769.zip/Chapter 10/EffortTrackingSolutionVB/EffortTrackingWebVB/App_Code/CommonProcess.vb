Imports Microsoft.VisualBasic
Imports System.Data

Public Class CommonProcess
    Public Shared Sub LoadWeekEndingCombo(ByVal combo As DropDownList)
        Dim s As localhost.Service = New localhost.Service()
        Dim ds As DataSet = s.GetLookupInfo()
        combo.DataSource = ds.Tables("Week Ending")
        combo.DataTextField = "we_end"
        combo.DataTextFormatString = "{0:MM/dd/yyyy}"
        combo.DataValueField = "we_id"
        combo.DataBind()
    End Sub

    Public Shared Sub LoadCategoryCombo(ByVal combo As DropDownList)
        Dim s As localhost.Service = New localhost.Service()
        Dim ds As DataSet = s.GetLookupInfo()
        combo.DataSource = ds.Tables("Categories")
        combo.DataTextField = "cat_title"
        combo.DataValueField = "cat_id"
        combo.DataBind()
    End Sub
End Class