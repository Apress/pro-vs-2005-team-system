Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data
Imports System.Data.SqlClient

<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class Service : Inherits System.Web.Services.WebService : Implements ITaskService
    ''' <summary>
    ''' Returns a dataset containing week and category information for use as lookups.
    ''' </summary>
    <WebMethod()> _
    Public Function GetLookupInfo() As System.Data.DataSet Implements ITaskService.GetLookupInfo
        Dim ds As DataSet = New DataSet()
        Dim cn As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("db").ToString())
        Dim cmd1 As SqlCommand = New SqlCommand("SELECT * FROM categories", cn)
        Dim cmd2 As SqlCommand = New SqlCommand("SELECT * FROM week_ending", cn)
        Dim da1 As SqlDataAdapter = New SqlDataAdapter(cmd1)
        Dim da2 As SqlDataAdapter = New SqlDataAdapter(cmd2)

        ds.Tables.Add("Categories")
        ds.Tables.Add("Week Ending")

        da1.Fill(ds.Tables("Categories"))
        da2.Fill(ds.Tables("Week Ending"))

        Return ds
    End Function

    ''' <summary>
    ''' Validates that the user is in the system.
    ''' </summary>
    ''' <param name="userName">User name of the person to validate.</param>
    ''' <param name="password">Password to validate.</param>
    ''' <param name="type">Indicates if the password is encrypted or not.</param>
    <WebMethod()> _
    Public Function ValidateUser(ByVal userName As String, ByVal password As String, _
ByVal type As PasswordType) As Integer Implements ITaskService.ValidateUser
        If type = PasswordType.ClearText Then
            Dim cn As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("db").ToString())
            Dim cmd As SqlCommand = New SqlCommand("SELECT own_id FROM owners " _
                & "WHERE own_login = @userName and own_password = @pass", cn)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@userName", userName)
            cmd.Parameters.AddWithValue("@pass", password)
            cn.Open()
            Dim result As Object = cmd.ExecuteScalar()
            cn.Close()
            Dim value As Integer = IIf(result <> Nothing, Convert.ToInt32(result), 0)

            Return value
        Else
            Throw New ApplicationException("Encrypted password types are not supported at Me time.")
        End If
    End Function

    ''' <summary>
    ''' Adds a new user to the system.
    ''' </summary>
    ''' <param name="userName">User name of the person to add.</param>
    ''' <param name="password">Password for the new user.</param>
    <WebMethod()> _
    Public Function AddUser(ByVal userName As String, ByVal password As String) _
    As Integer Implements ITaskService.AddUser
        If userName.Length = 0 Or password.Length = 0 Then
            Throw New Exception("The username or password may not be empty.")
        End If

        Dim cn As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("db").ToString())
        Dim cmd As SqlCommand = New SqlCommand("INSERT INTO owners (own_login, own_password) " _
            & "VALUES (@userName, @pass)", cn)
        cmd.CommandType = CommandType.Text
        cmd.Parameters.AddWithValue("@userName", userName)
        cmd.Parameters.AddWithValue("@pass", password)
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()

        Return ValidateUser(userName, password, PasswordType.ClearText)
    End Function

    ''' <summary>
    ''' Deletes a single task item.
    ''' </summary>
    ''' <param name="taskID">ID of the task to delete.</param>
    <WebMethod()> _
    Public Sub DeleteTask(ByVal taskID As Integer) Implements ITaskService.DeleteTask
        Dim cn As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("db").ToString())
        Dim cmd As SqlCommand = New SqlCommand("DELETE FROM work_items WHERE " _
            & " wi_id = @id", cn)
        cmd.CommandType = CommandType.Text
        cmd.Parameters.AddWithValue("@id", taskID)
        cn.Open()
        cmd.ExecuteNonQuery()
        cn.Close()
    End Sub

    ''' <summary>
    ''' Returns a single task.
    ''' </summary>
    ''' <param name="taskID">The ID of the task to return.</param>
    <WebMethod()> _
    Public Function GetTask(ByVal taskID As Integer) As Task Implements ITaskService.GetTask
        Dim cn As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("db").ToString())
        Dim cmd As SqlCommand = New SqlCommand("SELECT * FROM work_items WHERE " _
            & "wi_id = @id", cn)
        Dim dr As SqlDataReader
        Dim task As Task = New Task()

        cmd.CommandType = CommandType.Text
        cmd.Parameters.AddWithValue("@id", taskID)

        cn.Open()
        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While (dr.Read())
            task.Id = taskID
            task.Title = dr("wi_title").ToString()
            task.Description = dr("wi_description").ToString()
            task.DateModified = Convert.ToDateTime(dr("wi_modified_date"))
            task.UserId = Convert.ToInt32(dr("own_id"))
            task.WeekEndingId = Convert.ToInt32(dr("we_id"))
            task.CategoryId = Convert.ToInt32(dr("cat_id"))
        End While

        Return task
    End Function

    ''' <summary>
    ''' Returns a dataset with Task information for the given week and user.
    ''' </summary>
    ''' <param name="weekID">ID of the week for which to return the tasks.</param>
    ''' <param name="userID">ID of the user to return the tasks for.</param>
    <WebMethod()> _
    Public Function GetTasks(ByVal weekID As Integer, ByVal userID As Integer) _
    As DataSet Implements ITaskService.GetTasks
        Dim cn As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("db").ToString())
        Dim cmd As SqlCommand = New SqlCommand("SELECT wi_id, wi_title, cat_title FROM work_items a " _
            & "join categories b on a.cat_id = b.cat_id WHERE " _
            & "we_id = @we_id and own_id = @own_id", cn)
        Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
        Dim ds As DataSet = New DataSet()

        cmd.CommandType = CommandType.Text
        cmd.Parameters.AddWithValue("@we_id", weekID)
        cmd.Parameters.AddWithValue("@own_id", userID)

        da.Fill(ds)

        Return ds
    End Function

    ''' <summary>
    ''' Gets a weeks worth of tasks based for the week the date provided by the user
    ''' falls in.
    ''' </summary>
    ''' <param name="dateToGet">The date for the week to retrieve the tasks.</param>
    ''' <param name="userID">The ID of the user.</param>
    ''' <returns>A dataset with the partial tasks.</returns>
    <WebMethod()> _
    Public Function GetTasksWithDate(ByVal dateToGet As Date, ByVal userID As Integer) _
    As DataSet Implements ITaskService.GetTasksWithDate
        Dim cn As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("db").ToString())
        Dim cmd As SqlCommand = New SqlCommand("SELECT we_id FROM week_ending WHERE @date " _
            & "BETWEEN we_start AND we_end", cn)
        cmd.CommandType = CommandType.Text
        cmd.Parameters.AddWithValue("@date", dateToGet)

        cn.Open()
        Dim result As Object = cmd.ExecuteScalar()
        cn.Close()

        Dim dateId As Integer = IIf(result <> Nothing, Convert.ToInt32(result), 0)

        Return GetTasks(dateId, userID)
    End Function

    ''' <summary>
    ''' Saves or updates a task in the database.
    ''' </summary>
    ''' <param name="taskToSave">Task to save.</param>
    <WebMethod()> _
    Public Function SaveTask(ByVal taskToSave As Task) As Integer Implements ITaskService.SaveTask
        Dim cn As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("db").ToString())
        Dim cmd As SqlCommand = New SqlCommand()
        Dim sql As String = ""
        Dim sqlGetId As String = ""

        Dim ReturnTaskId As Integer = 0

        cmd.CommandType = CommandType.Text
        cmd.Connection = cn

        taskToSave.DateModified = DateTime.Now
        If taskToSave.Id = 0 Then
            sql = "INSERT INTO work_items (wi_title, wi_description, wi_modified_date, " _
            & "cat_id, own_id, we_id) VALUES (@title, @desc, @modified, @cat_id, @own_id, " _
            & "@we_id)"

            sqlGetId = "SELECT wi_id FROM work_items WHERE wi_title = @title and " _
            & "wi_description = @desc and wi_modified_date = @modified and " _
            & "cat_id = @cat_id and we_id = @we_id and own_id = @own_id"
        Else 'This is an update Then 
            sql = "UPDATE work_items SET wi_title = @title, wi_description = @desc, " _
            & "wi_modified_date = @modified, cat_id = @cat_id, own_id = @own_id, " _
            & "we_id = @we_id WHERE wi_id = @id"
            cmd.Parameters.AddWithValue("@id", taskToSave.Id)
        End If

        cmd.CommandText = sql

        cmd.Parameters.AddWithValue("@title", taskToSave.Title)
        cmd.Parameters.AddWithValue("@desc", taskToSave.Description)
        cmd.Parameters.AddWithValue("@modified", taskToSave.DateModified)
        cmd.Parameters.AddWithValue("@cat_id", taskToSave.CategoryId)
        cmd.Parameters.AddWithValue("@we_id", taskToSave.WeekEndingId)
        cmd.Parameters.AddWithValue("@own_id", taskToSave.UserId)

        cn.Open()
        cmd.ExecuteNonQuery()

        'If the ID is zero, run another sql statement to get the new ID back
        If taskToSave.Id = 0 Then
            Dim cmdId As SqlCommand = New SqlCommand(sqlGetId, cn)
            cmdId.CommandType = CommandType.Text
            cmdId.Parameters.AddWithValue("@title", taskToSave.Title)
            cmdId.Parameters.AddWithValue("@desc", taskToSave.Description)
            cmdId.Parameters.AddWithValue("@modified", taskToSave.DateModified)
            cmdId.Parameters.AddWithValue("@cat_id", taskToSave.CategoryId)
            cmdId.Parameters.AddWithValue("@we_id", taskToSave.WeekEndingId)
            cmdId.Parameters.AddWithValue("@own_id", taskToSave.UserId)
            ReturnTaskId = Convert.ToInt32(cmdId.ExecuteScalar())
        End If

        cn.Close()

        Return ReturnTaskId
    End Function
End Class