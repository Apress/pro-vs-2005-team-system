Imports Microsoft.VisualBasic

Public Enum PasswordType
    ''' <summary>
    ''' Indicates the password is unencrypted.
    ''' </summary>
    ClearText = 0
    ''' <summary>
    ''' Indicates the password is encrypted.
    ''' </summary>
    Encrypted = 1
End Enum
