Imports Microsoft.VisualBasic

Public Structure Task
    ''' <summary>
    ''' ID of the task.
    ''' </summary>
    Public Id As Integer
    ''' <summary>
    ''' Brief description of the task.
    ''' </summary>
    Public Title As String
    ''' <summary>
    ''' Complete description of the task.
    ''' </summary>
    Public Description As String
    ''' <summary>
    ''' Date the task was last updated.
    ''' </summary>
    Public DateModified As Date
    ''' <summary>
    ''' ID of the week in which the task was performed.
    ''' </summary>
    Public WeekEndingId As Integer
    ''' <summary>
    ''' ID of the category which the task falls under.
    ''' </summary>
    Public CategoryId As Integer
    ''' <summary>
    ''' ID of the user who created and owns the task.
    ''' </summary>
    Public UserId As Integer
End Structure