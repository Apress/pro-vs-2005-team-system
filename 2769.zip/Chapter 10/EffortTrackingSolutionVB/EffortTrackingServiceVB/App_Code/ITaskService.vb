Imports Microsoft.VisualBasic
Imports System.Data

Public Interface ITaskService
    Function AddUser(ByVal userName As String, ByVal password As String) As Integer
    Sub DeleteTask(ByVal taskID As Integer)
    Function GetLookupInfo() As DataSet
    Function GetTask(ByVal taskID As Integer) As Task
    Function GetTasks(ByVal weekID As Integer, ByVal userID As Integer) As DataSet
    Function GetTasksWithDate(ByVal dateToGet As Date, ByVal userID As Integer) As DataSet
    Function SaveTask(ByVal taskToSave As Task) As Integer
    Function ValidateUser(ByVal userName As String, ByVal password As String, ByVal type As PasswordType) As Integer
End Interface
