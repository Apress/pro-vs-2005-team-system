In order for the walkthrough to work for this chapter, the entire solution must be added to version control and set up. To do this, do the following:

1. 	Add a Virtual Directory to IIS called EffortTrackingService and point it to the EffortTrackingService 
	(or EffortTrackingServiceVB) folder. 

2. 	Once the virtual directory is created, change the following in the properties dialog of IIS:
		a. Make sure that the site is running under ASP.NET 2.0 on the ASP.NET tab

3. 	Add a Virtual Directory to IIS called EffortTrackingWeb and point it to the EffortTrackingWeb 
	(or EffortTrackingWebVB) folder.

4. 	Once the virtual directory is created, change the following in the properties dialog of IIS:
		a. Make sure that the site is running under ASP.NET 2.0 on the ASP.NET tab

5. 	Open the EffortTracking Solution.

6. 	Create the EffortTracking database.
		a. This can be on the local machine or another machine. It can use SQL Express or SQL Server. 
			Please note however that there is a small problem in VSTS in that it cannot use SQL 
			Express as a data source provider for data-driven Web Tests (chapter 15) and as such 
			is not the ideal candidate for you to use. 
		b. Create a SQL Login with the username and password of: uid=effortuser;pwd=pass@word1 (note, 
			if SQL Server is not in mixed mode, place it into mixed mode by right-clicking the 
			server name in the SQL Server Management Studio and selecting Properties > Security 
			and selecting Mixed Mode Authentication). See step 9 for an additional option.

	--------------------------------------------------------------------------------------------------------
	PLEASE NOTE, DO NOT DO THIS ON A PRODUCTION DATABASE OR A DATABASE IN USE IN YOUR ORGANIZATION. ONLY 
	DO THIS ON A TEST DATABASE OTHERWISE YOU MAY OPEN YOURSELF UP TO POSSIBLE SECURITY BREACHES. THE AUTHORS 
	TAKE NO RESPONSIBILITY IF YOU PERFORM THIS OPERATION ON A NON-DEVELOPMENT SYSTEM.
	--------------------------------------------------------------------------------------------------------

7. 	Expand the EffortTrackingDatabase project, right-click the DatabaseReferences node and select New Database
	Reference.
		a. Select the database you created in Step 6.

8. 	Open a Visual Studio Command Prompt and navigate to the EffortTrackingServiceTests folder (if you copied 
	the downloaded code to C:\ then the path would be 
	C:\4606\Full Application\EffortTrackingSolution\EffortTrackingServiceTests). Then, execute the following 
	line: sqlcmd -e -s localhost -d efforttracking -i DatabaseTestSetup.bat -o c:\results.txt
		a. This will create all of the tables and load them with test data (the c:\results.txt file is a log 
			file)
		b. If for some reason this does NOT work, you can right-click each of the .SQL items in the Create 
			Scripts and Queries folder one at a time, top to bottom and select Run.

9. 	Finally, change the connection string in the configuration file in the EffortTrackingService project to point 
	to the right database server. If you want, you can also use integrated authentication to connect to the 
	database but that will require you to add an 
	<identity impersonate="true" userName="[name]" password="[password" /> to the web.config file in the 
	EffortTrackingService application which is not a recommended course of action.

10. 	Once you've done all of the above, you should be able to run the application