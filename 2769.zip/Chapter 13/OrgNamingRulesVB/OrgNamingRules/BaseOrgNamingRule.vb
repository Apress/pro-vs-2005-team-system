Imports Microsoft.FxCop.Sdk.Introspection

Public MustInherit Class BaseOrgNamingRule : Inherits BaseIntrospectionRule
    Protected Sub New()
        Me.New("BaseOrgNamingRule")
    End Sub
    Protected Sub New(ByVal name As String)
        MyBase.New(name, "OrgNamingRules.Rules", GetType(BaseOrgNamingRule).Assembly)
    End Sub
End Class
