Imports Microsoft.FxCop.Sdk.Introspection
Imports Microsoft.FxCop.Sdk

Public Class UnderscorePrefixRule : Inherits BaseOrgNamingRule
    Public Sub New()
        MyBase.New("UnderscorePrefixRule")
    End Sub

    Public Overrides Function Check(ByVal member As Microsoft.Cci.Member) As ProblemCollection
        If member Is Nothing OrElse member.IsPublic Then
            Return Nothing
        End If

        If member.NodeType = Microsoft.Cci.NodeType.Field Then
            If Not member.Name.Name.StartsWith("_") Then
                Dim textArray1 As String() = New String(0) {RuleUtilities.Format(member)}
                Dim resolution1 As Resolution = Me.GetNamedResolution("Member", textArray1)
                Dim problem1 As Problem = New Problem(resolution1)
                Me.Problems.Add(problem1)
                Return Me.Problems
            Else
                Return Nothing
            End If
        Else
            Return Nothing
        End If

    End Function
End Class