using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.FxCop.Sdk.Introspection;

namespace OrgNamingRules
{
    public abstract class BaseOrgNamingRule: BaseIntrospectionRule
    {
        protected BaseOrgNamingRule() : this("BaseOrgNamingRule") { }
        protected BaseOrgNamingRule(string name) : base(name, "OrgNamingRules.Rules", typeof(BaseOrgNamingRule).Assembly) { }
    }
}