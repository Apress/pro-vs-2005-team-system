using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.FxCop.Sdk.Introspection;
using Microsoft.FxCop.Sdk;

namespace OrgNamingRules
{
    public class UnderscorePrefixRule:BaseOrgNamingRule
    {
        public UnderscorePrefixRule() : base("UnderscorePrefixRule") { }

        public override ProblemCollection Check(Microsoft.Cci.Member member)
        {
            if (member == null || member.IsPublic)
            { 
                return null; 
            }

            if (member.NodeType == Microsoft.Cci.NodeType.Field)
            {
                if (!member.Name.Name.StartsWith("_"))
                {
                    string[] textArray1 = new string[1] { RuleUtilities.Format(member) };
                    Resolution resolution1 = this.GetNamedResolution("Member", textArray1);
                    Problem problem1 = new Problem(resolution1, "Member");
                    base.Problems.Add(problem1);
                    return base.Problems;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
        }
    }
}