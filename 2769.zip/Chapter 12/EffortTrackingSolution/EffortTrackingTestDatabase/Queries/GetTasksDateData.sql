SET IDENTITY_INSERT dbo.get_tasks_date_test ON

INSERT INTO [dbo].[get_tasks_date_test] ([td_id], [td_date],[td_own_id],[td_expected],[td_description],[td_exception]) VALUES (1,'5/1/2005 12:00:00 AM',	1,	3,	'Test a boundary date/time (should work).',	'Testing a boundary date value with a valid owner failed.')
INSERT INTO [dbo].[get_tasks_date_test] ([td_id], [td_date],[td_own_id],[td_expected],[td_description],[td_exception]) VALUES (2,'5/6/2005 12:00:00 AM',	1,	3,	'Test a mid-line date value with a valid user.','Testing a mid-line date value with a valid user failed.')
INSERT INTO [dbo].[get_tasks_date_test] ([td_id], [td_date],[td_own_id],[td_expected],[td_description],[td_exception]) VALUES (3,'5/10/2005 12:00:00 AM',1,	2,	'Test another valid value.','Testing the second week with a valid value failed.')
INSERT INTO [dbo].[get_tasks_date_test] ([td_id], [td_date],[td_own_id],[td_expected],[td_description],[td_exception]) VALUES (4,'6/1/2005 12:00:00 AM',	1,	0,	'Testing a date that doesn''t exist in the system.','Testing an invalid date failed.')
INSERT INTO [dbo].[get_tasks_date_test] ([td_id], [td_date],[td_own_id],[td_expected],[td_description],[td_exception]) VALUES (5,'5/2/2005 12:00:00 AM',	0,	0,	'Testing a valid date and an invalid user.','Testing a valid date but an invalid user failed.')

           
SET IDENTITY_INSERT dbo.get_tasks_date_test OFF 