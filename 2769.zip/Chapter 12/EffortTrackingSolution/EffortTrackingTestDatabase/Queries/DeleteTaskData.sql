SET IDENTITY_INSERT dbo.delete_task_test ON

INSERT INTO delete_task_test (dt_id, dt_wi_id, dt_description, dt_exception) VALUES (1, 2, 'Delete an existing task.','Deleting an existing task failed.')
INSERT INTO delete_task_test (dt_id, dt_wi_id, dt_description, dt_exception) VALUES (2,	25, 'Delete a task that does not exist.', 'Deleting an invalid task failed.')

SET IDENTITY_INSERT dbo.delete_task_test OFF