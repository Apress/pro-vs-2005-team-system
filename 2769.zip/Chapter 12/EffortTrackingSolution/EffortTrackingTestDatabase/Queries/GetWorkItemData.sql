SET IDENTITY_INSERT dbo.get_work_item_test ON

INSERT INTO [dbo].[get_work_item_test] ([gw_id], [gw_task_id] ,[gw_title],[gw_description],[gw_date_modified],[gw_cat_id],[gw_own_id],[gw_we_id],[gw_test_description],[gw_exception]) VALUES (1,1,'Work Item 1','Description of Work Item 1',	'11/6/2005 9:02:39 AM',1,1,1,'Retrieve a valid task.','Retrieving a valid task failed.')
INSERT INTO [dbo].[get_work_item_test] ([gw_id], [gw_task_id] ,[gw_title],[gw_description],[gw_date_modified],[gw_cat_id],[gw_own_id],[gw_we_id],[gw_test_description],[gw_exception]) VALUES (2,0,'invalid','invalid','11/6/2005 9:02:39 AM',1,1,1,'Retrieve an invalid task number (will cause an empty task to be returned so the values are irrelevant.','Retrieving an invalid task failed.')

SET IDENTITY_INSERT dbo.get_work_item_test OFF 