SET IDENTITY_INSERT dbo.validate_user_test ON

INSERT INTO [dbo].[validate_user_test] ([vu_id], [vu_username],[vu_password],[vu_password_type],[vu_expected],[vu_description],[vu_exception]) VALUES (1,'TestUser1','password',0,1,'A valid username and password where the user exists in the system.','Test for an existing, valid username/password failed.')
INSERT INTO [dbo].[validate_user_test] ([vu_id], [vu_username],[vu_password],[vu_password_type],[vu_expected],[vu_description],[vu_exception]) VALUES (2,'TestUser1','password',1,0,'A valid username/password but an unimplemented encryption type.','Test for an unimplemented encryption type failed.')
INSERT INTO [dbo].[validate_user_test] ([vu_id], [vu_username],[vu_password],[vu_password_type],[vu_expected],[vu_description],[vu_exception]) VALUES (3,'User1','password',0,0,'An invalid username with a valid password.','Test for an invalid username failed.')
INSERT INTO [dbo].[validate_user_test] ([vu_id], [vu_username],[vu_password],[vu_password_type],[vu_expected],[vu_description],[vu_exception]) VALUES (4,'TestUser1','badpassword',0,0,'A valid username and invalid password.','Test for a valid username but invalid password failed.')
INSERT INTO [dbo].[validate_user_test] ([vu_id], [vu_username],[vu_password],[vu_password_type],[vu_expected],[vu_description],[vu_exception]) VALUES (5,'TestUser1',NULL,0,0,'A valid username but a null password.','Test for a valid username with a null password failed.')
INSERT INTO [dbo].[validate_user_test] ([vu_id], [vu_username],[vu_password],[vu_password_type],[vu_expected],[vu_description],[vu_exception]) VALUES (6,NULL,'password',0,0,'A null username and an invalid password.','Test for a null username and valid password failed.')

SET IDENTITY_INSERT dbo.validate_user_test OFF 