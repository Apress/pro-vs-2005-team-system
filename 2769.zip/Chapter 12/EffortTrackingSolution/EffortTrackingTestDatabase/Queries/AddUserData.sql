SET IDENTITY_INSERT dbo.add_user_test ON

INSERT INTO add_user_test (au_id, au_username, au_password, au_expected, au_description, au_exception) VALUES (1,'TestUser','password',3,'Test a good username / password combination.','Adding a valid username/password combination failed.')
INSERT INTO add_user_test (au_id, au_username, au_password, au_expected, au_description, au_exception) VALUES (2,'Test User',NULL,0,'Add a user with a null password.','Adding a user with a null password failed.')
INSERT INTO add_user_test (au_id, au_username, au_password, au_expected, au_description, au_exception) VALUES (3,NULL,'password',0,'Add a user with a null username.','Adding a user with a null username failed.')
INSERT INTO add_user_test (au_id, au_username, au_password, au_expected, au_description, au_exception) VALUES (4,'This is a very long username which is over 50 characters.','password',0,'Add a user with more than the allowed length of characters and a valid password.','Adding a user with a username greater than 50 characters in length failed.')
INSERT INTO add_user_test (au_id, au_username, au_password, au_expected, au_description, au_exception) VALUES (6,'TestUser','This is a very long password which is over 50 characters.',0,'Add a user with a valid username and a password longer than the allowed length.','Adding a user with a password greather than 50 characters failed.')
INSERT INTO add_user_test (au_id, au_username, au_password, au_expected, au_description, au_exception) VALUES (7,'TestUser1','password',0,'Add a user with a duplicate username. The original username is preloaded by the testinitialization method.','Adding a user with a duplicate username failed.')

SET IDENTITY_INSERT dbo.add_user_test OFF
