SET IDENTITY_INSERT dbo.get_items_test ON

INSERT INTO [dbo].[get_items_test] ([gi_id], [gi_own_id] ,[gi_we_id] ,[gi_expected] ,[gi_description] ,[gi_exception]) VALUES (1,	1,	1,	3,	'Get one weeks worth of times.',	'Getting items for owner 1 and week 1 failed.')
INSERT INTO [dbo].[get_items_test] ([gi_id], [gi_own_id] ,[gi_we_id] ,[gi_expected] ,[gi_description] ,[gi_exception]) VALUES (2,	2,	1,	2,	'Get one weeks worth of work items.',	'Getting items for owner 2 and week 1 failed.')
INSERT INTO [dbo].[get_items_test] ([gi_id], [gi_own_id] ,[gi_we_id] ,[gi_expected] ,[gi_description] ,[gi_exception]) VALUES (3,	0,	1,	0,	'Test an invalid owner ID.',	'Getting items for an invalid owner ID failed.')
INSERT INTO [dbo].[get_items_test] ([gi_id], [gi_own_id] ,[gi_we_id] ,[gi_expected] ,[gi_description] ,[gi_exception]) VALUES (4,	1,	9,	0,	'Test an invalid week ending.',	'Getting items for an invalid week ending failed.')

SET IDENTITY_INSERT dbo.get_items_test OFF 