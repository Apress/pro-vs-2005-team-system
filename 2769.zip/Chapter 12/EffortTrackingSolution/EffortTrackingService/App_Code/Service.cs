using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace EffortTrackingService
{
    /// <summary>
    /// Summary description for Service
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class Service : System.Web.Services.WebService, ITaskService
    {
        /// <summary>
        /// Returns a dataset containing week and category information for use as lookups.
        /// </summary>
        [WebMethod()]
        public System.Data.DataSet GetLookupInfo()
        {
            DataSet ds = new DataSet();
            SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ToString());
            SqlCommand cmd1 = new SqlCommand("SELECT * FROM categories", cn);
            SqlCommand cmd2 = new SqlCommand("SELECT * FROM week_ending", cn);
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            SqlDataAdapter da2 = new SqlDataAdapter(cmd2);

            ds.Tables.Add("Categories");
            ds.Tables.Add("Week Ending");

            da1.Fill(ds.Tables["Categories"]);
            da2.Fill(ds.Tables["Week Ending"]);

            return ds;
        }

        /// <summary>
        /// Validates that the user is in the system.
        /// </summary>
        /// <param name="userName">User name of the person to validate.</param>
        /// <param name="password">Password to validate.</param>
        /// <param name="type">Indicates if the password is encrypted or not.</param>
        [WebMethod()]
        public int ValidateUser(string userName, string password, PasswordType type)
        {
            if (type == EffortTrackingService.PasswordType.ClearText)
            {
                SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ToString());
                SqlCommand cmd = new SqlCommand("SELECT own_id FROM owners "
                    + "WHERE own_login = @userName and own_password = @pass", cn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@userName", userName);
                cmd.Parameters.AddWithValue("@pass", password);
                cn.Open();
                object result = cmd.ExecuteScalar();
                cn.Close();
                int value = (result != null) ? Convert.ToInt32(result) : 0;
                return value;
            }
            else
            {
                throw new ApplicationException("Encrypted password types are not supported at this time.");
            }
        }

        /// <summary>
        /// Adds a new user to the system.
        /// </summary>
        /// <param name="userName">User name of the person to add.</param>
        /// <param name="password">Password for the new user.</param>
        [WebMethod()]
        public int AddUser(string userName, string password)
        {
            if (userName.Length == 0 || password.Length == 0)
                throw new Exception("The username or password may not be empty.");

            SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ToString());
            SqlCommand cmd = new SqlCommand("INSERT INTO owners (own_login, own_password) "
                + "VALUES (@userName, @pass)", cn);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@userName", userName);
            cmd.Parameters.AddWithValue("@pass", password);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();

            return ValidateUser(userName, password, PasswordType.ClearText);
        }

        /// <summary>
        /// Deletes a single task item.
        /// </summary>
        /// <param name="taskID">ID of the task to delete.</param>
        [WebMethod()]
        public void DeleteTask(int taskID)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ToString());
            SqlCommand cmd = new SqlCommand("DELETE FROM work_items WHERE "
                + " wi_id = @id", cn);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", taskID);
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
        }

        /// <summary>
        /// Returns a single task.
        /// </summary>
        /// <param name="taskID">The ID of the task to return.</param>
        [WebMethod()]
        public Task GetTask(int taskID)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ToString());
            SqlCommand cmd = new SqlCommand("SELECT * FROM work_items WHERE "
                + "wi_id = @id", cn);
            SqlDataReader dr;
            Task task = new Task();

            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", taskID);

            cn.Open();
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
            while (dr.Read())
            {
                task.Id = taskID;
                task.Title = dr["wi_title"].ToString();
                task.Description = dr["wi_description"].ToString();
                task.DateModified = Convert.ToDateTime(dr["wi_modified_date"]);
                task.UserId = Convert.ToInt32(dr["own_id"]);
                task.WeekEndingId = Convert.ToInt32(dr["we_id"]);
                task.CategoryId = Convert.ToInt32(dr["cat_id"]);
            }

            return task;
        }

        /// <summary>
        /// Returns a dataset with Task information for the given week and user.
        /// </summary>
        /// <param name="weekID">ID of the week for which to return the tasks.</param>
        /// <param name="userID">ID of the user to return the tasks for.</param>
        [WebMethod()]
        public DataSet GetTasks(int weekID, int userID)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ToString());
            SqlCommand cmd = new SqlCommand("SELECT wi_id, wi_title, cat_title FROM work_items a "
                + "join categories b on a.cat_id = b.cat_id WHERE "
                + "we_id = @we_id and own_id = @own_id", cn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@we_id", weekID);
            cmd.Parameters.AddWithValue("@own_id", userID);

            da.Fill(ds);

            return ds;
        }

        /// <summary>
        /// Gets a weeks worth of tasks based for the week the date provided by the user
        /// falls in.
        /// </summary>
        /// <param name="date">The date for the week to retrieve the tasks.</param>
        /// <param name="userID">The ID of the user.</param>
        /// <returns>A dataset with the partial tasks.</returns>
        [WebMethod()]
        public DataSet GetTasksWithDate(DateTime date, int userID)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ToString());
            SqlCommand cmd = new SqlCommand("SELECT we_id FROM week_ending WHERE @date "
                + "BETWEEN we_start AND we_end", cn);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@date", date);

            cn.Open();
            object result = cmd.ExecuteScalar();
            cn.Close();

            int dateId = result != null ? Convert.ToInt32(result) : 0;

            return GetTasks(dateId, userID);
        }

        /// <summary>
        /// Saves or updates a task in the database.
        /// </summary>
        /// <param name="task">Task to save.</param>
        [WebMethod()]
        public int SaveTask(Task task)
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["db"].ToString());
            SqlCommand cmd = new SqlCommand();
            string sql = "";
            string sqlGetId = "";

            int returnTaskId = 0;

            cmd.CommandType = CommandType.Text;
            cmd.Connection = cn;

            task.DateModified = DateTime.Now;
            if (task.Id == 0)   //This is an insert
            {
                sql = "INSERT INTO work_items (wi_title, wi_description, wi_modified_date, "
                + "cat_id, own_id, we_id) VALUES (@title, @desc, @modified, @cat_id, @own_id, "
                + "@we_id)";

                sqlGetId = "SELECT wi_id FROM work_items WHERE wi_title = @title and "
                + "wi_description = @desc and wi_modified_date = @modified and "
                + "cat_id = @cat_id and we_id = @we_id and own_id = @own_id";
            }
            else //This is an update
            {
                sql = "UPDATE work_items SET wi_title = @title, wi_description = @desc, "
                + "wi_modified_date = @modified, cat_id = @cat_id, own_id = @own_id, "
                + "we_id = @we_id WHERE wi_id = @id";
                cmd.Parameters.AddWithValue("@id", task.Id);
            }

            cmd.CommandText = sql;

            cmd.Parameters.AddWithValue("@title", task.Title);
            cmd.Parameters.AddWithValue("@desc", task.Description);
            cmd.Parameters.AddWithValue("@modified", task.DateModified);
            cmd.Parameters.AddWithValue("@cat_id", task.CategoryId);
            cmd.Parameters.AddWithValue("@we_id", task.WeekEndingId);
            cmd.Parameters.AddWithValue("@own_id", task.UserId);

            cn.Open();
            cmd.ExecuteNonQuery();

            //If the ID is zero, run another sql statement to get the new ID back
            if (task.Id == 0)
            {
                SqlCommand cmdId = new SqlCommand(sqlGetId, cn);
                cmdId.CommandType = CommandType.Text;
                cmdId.Parameters.AddWithValue("@title", task.Title);
                cmdId.Parameters.AddWithValue("@desc", task.Description);
                cmdId.Parameters.AddWithValue("@modified", task.DateModified);
                cmdId.Parameters.AddWithValue("@cat_id", task.CategoryId);
                cmdId.Parameters.AddWithValue("@we_id", task.WeekEndingId);
                cmdId.Parameters.AddWithValue("@own_id", task.UserId);
                returnTaskId = Convert.ToInt32(cmdId.ExecuteScalar());
            }

            cn.Close();

            return returnTaskId;
        }
    }
}