Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data
Imports System.Data.SqlClient

<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class Service : Inherits System.Web.Services.WebService : Implements ITaskService
    ''' <summary>
    ''' Returns a dataset containing week and category information for use as lookups.
    ''' </summary>
    <WebMethod()> _
    Public Function GetLookupInfo() As System.Data.DataSet Implements ITaskService.GetLookupInfo
        Throw New Exception("Method not implemented yet.")
    End Function

    ''' <summary>
    ''' Validates that the user is in the system.
    ''' </summary>
    ''' <param name="userName">User name of the person to validate.</param>
    ''' <param name="password">Password to validate.</param>
    ''' <param name="type">Indicates if the password is encrypted or not.</param>
    <WebMethod()> _
    Public Function ValidateUser(ByVal userName As String, ByVal password As String, _
ByVal type As PasswordType) As Integer Implements ITaskService.ValidateUser
        throw new Exception("Method not implemented yet.")
    End Function

    ''' <summary>
    ''' Adds a new user to the system.
    ''' </summary>
    ''' <param name="userName">User name of the person to add.</param>
    ''' <param name="password">Password for the new user.</param>
    <WebMethod()> _
    Public Function AddUser(ByVal userName As String, ByVal password As String) _
    As Integer Implements ITaskService.AddUser
        throw new Exception("Method not implemented yet.")
    End Function

    ''' <summary>
    ''' Deletes a single task item.
    ''' </summary>
    ''' <param name="taskID">ID of the task to delete.</param>
    <WebMethod()> _
    Public Sub DeleteTask(ByVal taskID As Integer) Implements ITaskService.DeleteTask
        throw new Exception("Method not implemented yet.")
    End Sub

    ''' <summary>
    ''' Returns a single task.
    ''' </summary>
    ''' <param name="taskID">The ID of the task to return.</param>
    <WebMethod()> _
    Public Function GetTask(ByVal taskID As Integer) As Task Implements ITaskService.GetTask
        throw new Exception("Method not implemented yet.")
    End Function

    ''' <summary>
    ''' Returns a dataset with Task information for the given week and user.
    ''' </summary>
    ''' <param name="weekID">ID of the week for which to return the tasks.</param>
    ''' <param name="userID">ID of the user to return the tasks for.</param>
    <WebMethod()> _
    Public Function GetTasks(ByVal weekID As Integer, ByVal userID As Integer) _
    As DataSet Implements ITaskService.GetTasks
        throw new Exception("Method not implemented yet.")
    End Function

    ''' <summary>
    ''' Gets a weeks worth of tasks based for the week the date provided by the user
    ''' falls in.
    ''' </summary>
    ''' <param name="dateToGet">The date for the week to retrieve the tasks.</param>
    ''' <param name="userID">The ID of the user.</param>
    ''' <returns>A dataset with the partial tasks.</returns>
    <WebMethod()> _
    Public Function GetTasksWithDate(ByVal dateToGet As Date, ByVal userID As Integer) _
    As DataSet Implements ITaskService.GetTasksWithDate
        throw new Exception("Method not implemented yet.")
    End Function

    ''' <summary>
    ''' Saves or updates a task in the database.
    ''' </summary>
    ''' <param name="taskToSave">Task to save.</param>
    <WebMethod()> _
    Public Function SaveTask(ByVal taskToSave As Task) As Integer Implements ITaskService.SaveTask
        throw new Exception("Method not implemented yet.")
    End Function
End Class